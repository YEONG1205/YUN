# blastpy
Blasteroid shooting game by python
